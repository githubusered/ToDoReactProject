import React, {useState,useEffect, useRef} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCircleCheck, faTrashCan
} from '@fortawesome/free-solid-svg-icons'

import './App.css';

function App() {
  
  // check checkbox completed or not
  // const [check,setCheck] = useState(false)
  const [completed,setCompleted] = useState([])
  const checkedRef = useRef()
  
  const checkCompletedTasks = () => {
    if(checkedRef.current.checked){
      let newTasks = toDo.filter(task => task.status)
      setCompleted(newTasks)
    }else{
      setCompleted(toDo)
    }
  }

  // Tasks (ToDo List) State
  const [toDo,setToDo] = useState([
    // {"id":1,"title":"Task 1", "status":false},
    // {"id":2,"title":"Task 2", "status":false},
  ])
  
  // Temp State
  const [newTask,setNewTask] = useState('');
  // Add task
  ////////////////////////////
  const addTask = () => {
    if(newTask){
      let num = toDo.length - 1;
      let newEntry = {id:num,title:newTask, status:false}
      setToDo([...toDo,newEntry])
      setNewTask('')
    }
  }

  // Delete task
  ////////////////////////////
  const deleteTask = (id) =>{
    let newTasks = toDo.filter(task => task.id !== id)
    setToDo(newTasks)
  }

  // Mark task  as done or completed
  ////////////////////////////
  const markDone = (id) =>{
    let newTask = toDo.map(task => {
      if(task.id === id) {
        return({...task, status: !task.status})
      }
      return task;
    })
    setToDo(newTask)
  }
  useEffect(() => {
    if (newTask.length > 54) {
      // eslint-disable-next-line no-undef
      // setInputInfo((s) => ({ ...s, lengthCount: 0 }));
    }
    setCompleted(toDo)

  }, [newTask,setNewTask, toDo]);
  return (
    <div className="container App">
      <br/><br/>
      <h2>To Do List with ReactJS</h2>
      <br/><br/>

      {/* Checkbox completed or not */}
      <div>
        <input type="checkbox" ref={checkedRef} onChange={checkCompletedTasks}/> Completed
      </div>

      {/* Add task */}
      <div className='row'>
          <div className='col'>
            <input className='form-control form-control-lg'
            value={newTask} onChange={(e) =>{
              setNewTask(e.target.value)
            }}/>
          </div>
          <div className='col-auto'>
            <button className='btn btn-lg btn-success' onClick={addTask}>
              Add</button>
          </div>
      </div>



      {/* Display ToDos */}
      {toDo && toDo.length ? '' : <div>Your life is a blank page. You write on it.</div>}
      {toDo && toDo.length ? '' : <div> So start by adding your tasks here.</div>}
      
      { completed 
        .sort((a,b) => a.id > b.id ? 1 : -1)
        .map((task) =>{
          return(
            <React.Fragment key={task.id}>
              <div className="col taskBg">
                  <div className={task.status ? 'done' : ''}>
                      <span className='check-icon icons' title='Completed / Not Completed' onClick={() => markDone(task.id)}>
                        <FontAwesomeIcon icon={faCircleCheck}/>
                      </span>
                      <span className='taskText'>{task.title}</span>
                      <span className='trash-icon icons' title='Delete' onClick={() => deleteTask(task.id)}>

                        <FontAwesomeIcon icon={faTrashCan}/>
                      </span>
                  </div>
              </div>
            </React.Fragment>)
        })
      }
    
    </div>
  );
}

export default App;
